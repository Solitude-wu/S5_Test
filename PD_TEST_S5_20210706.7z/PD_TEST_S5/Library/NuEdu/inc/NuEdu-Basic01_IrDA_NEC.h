#ifndef __NuEdu_Basic01_IrDA_NEC_H__
#define __NuEdu_Basic01_IrDA_NEC_H__
extern void SendNEC(uint8_t* data);
extern void IrDA_NEC_TxRx_Init(void);
extern void IrDA_NEC_Rx_Init(void);
extern void IrDA_NEC_Tx_Init(void);
#endif
