#ifndef __NuEdu_Basic01_ACMP_H__
#define __NuEdu_Basic01_ACMP_H__

extern void Open_ACMP(void);
extern uint32_t Get_ACMP(void);

#endif
