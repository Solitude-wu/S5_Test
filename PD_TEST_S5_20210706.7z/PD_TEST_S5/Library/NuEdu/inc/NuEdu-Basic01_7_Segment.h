#ifndef __NuEdu_Basic01_7_Segment_H__
#define __NuEdu_Basic01_7_Segment_H__

extern void Show_Seven_Segment(unsigned char no, unsigned char number);
extern void Open_Seven_Segment(void);
#endif
