#ifndef __NuEdu_Basic01_Buzzer_H__
#define __NuEdu_Basic01_Buzzer_H__

extern void Open_Buzzer(void);
extern void Write_Buzzer(unsigned  int frequence, unsigned int duty, unsigned int count);


#endif
