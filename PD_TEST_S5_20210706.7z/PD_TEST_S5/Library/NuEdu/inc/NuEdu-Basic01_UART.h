#ifndef __NuEdu_Basic01_UART_H__
#define __NuEdu_Basic01_UART_H__
extern void UART0_Init(void);

#endif
