#ifndef __NuEdu_Basic01_RGBLED_H__
#define __NuEdu_Basic01_RGBLED_H__
extern void Initial_PWM_LED(void);
extern void PWM_LED(unsigned char ch, unsigned int ch0_fre, unsigned int ch0_dut, unsigned int ch1_fre, unsigned int ch1_dut, unsigned int ch2_fre, unsigned int ch2_dut);

#endif
