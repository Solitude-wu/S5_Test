#ifndef __NuEdu_Basic01_PWMDAC_H__
#define __NuEdu_Basic01_PWMDAC_H__
extern void Initial_PWM_DAC(void);
extern void Write_PWMDAC(unsigned char Enable, unsigned char ch0_dut);
#endif
