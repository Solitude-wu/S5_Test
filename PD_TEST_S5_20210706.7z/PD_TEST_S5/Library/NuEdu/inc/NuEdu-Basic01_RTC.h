#ifndef __NuEdu_Basic01_RTC_H__
#define __NuEdu_Basic01_RTC_H__

extern void RTC_Init(void);
extern void RTC_SET(S_RTC_TIME_DATA_T sWriteRTC);
#endif
