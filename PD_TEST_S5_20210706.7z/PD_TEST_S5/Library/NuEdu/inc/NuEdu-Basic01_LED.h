#ifndef __NuEdu_Basic01_LED_H__
#define __NuEdu_Basic01_LED_H__

extern void Write_LED_Bar(uint32_t Number);
extern void Initial_LED(void);
extern void LED_On(unsigned int temp);
#endif
