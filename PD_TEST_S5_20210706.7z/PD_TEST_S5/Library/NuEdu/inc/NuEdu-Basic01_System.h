#ifndef __NuEdu_Basic01_System_H__
#define __NuEdu_Basic01_System_H__
void SYS_Init(void);

#endif
