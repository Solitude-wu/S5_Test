#ifndef __NuEdu_Basic01_Threshold_Knob_H__
#define __NuEdu_Basic01_Threshold_Knob_H__

extern void Open_Threshold_Knob(void);
extern void Close_Threshold_Knob(void);
extern uint32_t Get_Threshold_Knob(void);

#endif
