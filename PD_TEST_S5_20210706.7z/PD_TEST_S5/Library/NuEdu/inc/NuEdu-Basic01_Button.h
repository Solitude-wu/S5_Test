#ifndef __NuEdu_Basic01_Button_H__
#define __NuEdu_Basic01_Button_H__
extern void Initial_Key_Input(void);
extern unsigned char Get_Key_Input(void);
#endif
