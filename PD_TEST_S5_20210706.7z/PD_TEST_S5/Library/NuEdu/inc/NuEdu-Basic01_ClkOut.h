#ifndef __NuEdu_Basic01_ClkOut_H__
#define __NuEdu_Basic01_ClkOut_H__
extern void Open_CLK_OUT(void);
#endif
