#ifndef __NuEdu_Basic01_Interrupt_H__
#define __NuEdu_Basic01_Interrupt_H__

extern void Open_EINT0(void);
#endif
